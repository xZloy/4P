public class Listhods {
    Node initial = new Node(0, null);

    public Listhods() {
        initial = null;
    }

    boolean isListEmpty() {
        if (initial.equals(null)) {
            return true;
        } else {
            return false;
        }
    }

    public void push(int data) {
        Node aux = initial;
        if (isListEmpty()) {
            aux.setData(data);
        } else {
            Node temp = aux;
            while (aux.getNext == null) {
                temp = temp.getNext();
            }
            temp = temp.setNext(aux);
        }
    }

    public void pop() {

    }
}
