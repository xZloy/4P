import java.util.Scanner;

public class Principal {
    public static void main(String args[]) {
        menu();
    }

}

public void menu() {
    Scanner lector = new Scanner(System.in);
    Listhods methods = new Listhods();
    int opt = 0;
    do {
        System.out.println(
                "Bienvenido al sistema del examen diagnostico\n - Que opcion desea realizar? \n 1.Insertar datos en la lista. \n 2.Eliminar datos de la lista. \n 3.Salir");
        opt = lector.nextInt();
        switch (opt) {
            case 1:
                System.out.println("Dame un numero para ingresar: \n");
                int data = lector.nextInt();
                methods.push(data);
                break;
            case 2:
                methods.pop();
            default:
                System.out.println("ERROR: Opcion fuera de las opciones");
                break;
        }
    } while (opt != 0);

}
